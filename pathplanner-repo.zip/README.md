# PathPlanner: routine-aware career roadmap for B.Tech students

> Course project: Project Design (BCS3711 / BAI3711), Assignment 3 prototype.

**Live demo:** [ADD DEPLOYMENT URL]  
**Demo video (YouTube):** [ADD VIDEO URL]  
**Poster:** [ADD LINK OR FILE NAME]

## Problem addressed
B.Tech students who have a target job often learn from scattered videos and generic roadmaps that ignore their real
daily routine. Plans are abandoned, students are unsure which skills the job needs, and saved resources stay unfinished.
PathPlanner turns a target job and a weekly routine into a roadmap, a schedule that fits the student's free time, and reminders.

## Features
- Goal and routine input (target job, timeline, study days, free-time window, reminder lead time)
- Roadmap generation: AI roadmap through an optional serverless function, otherwise built-in templates
  (Data Analyst, Web Developer, ML Engineer, Cybersecurity Analyst, generic fallback)
- Scheduler that places lessons only inside the student's free slots, without overlaps
- In-page reminders before each lesson (and optional browser notifications)
- Mark lessons done or skipped, and replan missed lessons into upcoming free slots
- Learning dashboard: day streak, lessons and minutes this week, course completion
- Light and dark themes, mobile layout, accessibility attributes for screen readers

## Technologies
HTML, CSS and vanilla JavaScript (no framework, no external libraries) · localStorage for saving progress ·
optional Vercel serverless function (Node.js) calling an LLM API · Playwright (Python) for end-to-end tests.

## Project structure
```
index.html          the whole web app
api/roadmap.js      optional serverless function for AI roadmaps (Vercel)
tests/e2e_test.py   end-to-end test script (Playwright)
tests/results.json  latest recorded test results
```

## Run locally
1. Download or clone the repository.
2. Open the folder in VS Code and run `index.html` with the Live Server extension (or open the file in a browser).
3. Without the serverless function the app uses the built-in roadmap templates.

## Enable AI roadmaps (optional)
1. Deploy the repository on Vercel.
2. Add an environment variable `ANTHROPIC_API_KEY` in the Vercel project settings.
3. Set a spending limit on your API account. Never commit the key: this repository contains no secrets.

## Run the tests
```
pip install playwright
playwright install chromium
python tests/e2e_test.py
```

## Known limitations
- Reminders work only while the page is open; background push, email or Telegram reminders are future work.
- Resources are YouTube search links, not verified playlists.
- Progress is stored in the browser only: no login or cloud sync.
- Prototype scope: no medical or other sensitive data is processed.

## Team contributions
| Member | Contribution |
|---|---|
| [NAME] | [e.g. frontend and UI] |
| [NAME] | [e.g. scheduling logic and tests] |
| [NAME] | [e.g. serverless function and deployment] |
| [NAME] | [e.g. documentation, video and poster] |

## Third-party resources and licences
- No third-party JavaScript libraries or fonts are bundled (system font stack, inline SVG icon drawn for this project).
- Tests use Playwright (Apache-2.0).
- Hosting and optional AI API are third-party services subject to their own terms.
- [ADD your own licence for the code, for example MIT, if your instructor allows]

"""
End-to-end tests for PathPlanner (Playwright + Chromium, headless).

Run (from the project folder):
    pip install playwright && playwright install chromium
    python tests/e2e_test.py

The script serves index.html on http://localhost:8765, runs each test with a fixed
fake clock (Monday 26 Oct 2026) and prints/saves the real results to tests/results.json.
"""
import json, subprocess, sys, time, os, datetime
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = 8765
URL = f"http://localhost:{PORT}/index.html"
CLOCK = datetime.datetime(2026, 10, 26, 10, 0, 0)   # Monday 10:00
results = []

MOCK_AI = {"milestones": [
    {"title": "Mock module A", "tasks": [{"title": "Mock lesson 1", "minutes": 30, "q": "mock one"},
                                         {"title": "Mock lesson 2", "minutes": 45, "q": "mock two"}]},
    {"title": "Mock module B", "tasks": [{"title": "Mock lesson 3", "minutes": 25, "q": "mock three"}]}]}


def record(tid, feature, action, expected, actual, ok):
    results.append({"id": tid, "feature": feature, "action": action, "expected": expected,
                    "actual": actual, "status": "PASS" if ok else "FAIL"})
    print(tid, "PASS" if ok else "FAIL", "-", actual)


def new_page(browser, clock=CLOCK, width=1000, height=900):
    ctx = browser.new_context(viewport={"width": width, "height": height})
    page = ctx.new_page()
    page.clock.install(time=clock)
    page.goto(URL)
    return ctx, page


def state(page):
    return page.evaluate("JSON.parse(localStorage.getItem('pathplanner.v1')||'null')")


def generate(page, job="Data Analyst"):
    page.fill("#job", job)
    page.click("#gen")
    page.wait_for_selector("#road .hd", timeout=5000)


def main():
    srv = subprocess.Popen([sys.executable, "-m", "http.server", str(PORT), "--directory", ROOT],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1)
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()

            # T1 roadmap generation (no AI server -> built-in template fallback)
            ctx, pg = new_page(browser)
            generate(pg)
            st = state(pg)
            mods, lessons = len(st["ms"]), len(st["tasks"])
            info = pg.inner_text("#road .hd")
            record("TC1", "Roadmap generation (FR4)", "Enter target job 'Data Analyst', 12 months, default routine; press Generate",
                   "Roadmap with at least 4 modules and 12 lessons is shown; fallback source is stated",
                   f"{mods} modules, {lessons} lessons; source note shows 'built-in template': {'built-in template' in info}",
                   mods >= 4 and lessons >= 12 and "built-in template" in info)

            # T2 scheduling only inside free slots, allowed days, no overlap
            bad, overlap, prev = 0, 0, None
            for t in st["tasks"]:
                d = datetime.date.fromisoformat(t["date"])
                wd = (d.weekday() + 1) % 7          # JS getDay(): Sun=0
                if t["start"] < 19 * 60 or t["start"] + t["min"] > 21 * 60 or wd not in st["p"]["days"]:
                    bad += 1
                if prev and prev["date"] == t["date"] and t["start"] < prev["start"] + prev["min"]:
                    overlap += 1
                prev = t
            record("TC2", "Routine-fitted scheduling (FR3, FR6)", "Routine Mon-Fri, free time 7:00 PM to 9:00 PM; inspect every scheduled lesson",
                   "No lesson outside 7-9 PM or on Sat/Sun; no overlaps",
                   f"{lessons} lessons checked; outside window/day: {bad}; overlaps: {overlap}", bad == 0 and overlap == 0)
            ctx.close()

            # T3 input validation
            ctx, pg = new_page(browser)
            while pg.query_selector("#days button.on"):
                pg.click("#days button.on")      # list is re-rendered after every click
            pg.fill("#job", "Web Developer")
            pg.click("#gen")
            e1 = pg.inner_text("#err")
            pg.click("#days button:nth-child(1)")        # Mon back on
            pg.fill("#s", "19:00"); pg.fill("#e", "19:10")
            pg.click("#gen")
            e2 = pg.inner_text("#err")
            made = state(pg)
            record("TC3", "Input validation", "(a) Generate with no study day selected; (b) free window of only 10 minutes",
                   "Clear error message for each case and no roadmap is created",
                   f"(a) '{e1}'; (b) '{e2}'; roadmap saved: {bool(made and made.get('tasks'))}",
                   "at least one day" in e1 and "20 minutes" in e2 and not (made and made.get("tasks")))
            ctx.close()

            # T4 reminder fires before a lesson (clock 6:50 PM Monday, lead 15 min)
            ctx, pg = new_page(browser, clock=datetime.datetime(2026, 10, 26, 18, 50, 0))
            generate(pg)
            first = state(pg)["tasks"][0]
            pg.clock.run_for(16000)
            toasts = pg.eval_on_selector_all("#toast div", "e=>e.map(x=>x.textContent)")
            hit = [t for t in toasts if t.startswith("Reminder:")]
            record("TC4", "Reminders (FR7)", "Clock set to Mon 6:50 PM; first lesson scheduled 7:00 PM; reminder lead 15 min; wait one check cycle (15 s)",
                   "An in-page reminder naming the lesson and 7:00 PM appears",
                   f"first lesson at {first['start']//60}:{first['start']%60:02d}; reminders shown: {hit}",
                   len(hit) >= 1 and "7:00 PM" in hit[0])
            ctx.close()

            # T5 replan
            ctx, pg = new_page(browser)
            generate(pg)
            pg.click(".tabs button[data-v=today]")
            before = [t["date"] + str(t["start"]) for t in state(pg)["tasks"][:3]]
            pg.locator("[data-a=skip]").nth(0).click()
            pg.locator("[data-a=skip]").nth(1).click()
            sk = len([t for t in state(pg)["tasks"] if t["st"] == "skipped"])
            pg.click("[data-a=replan]")
            s2 = state(pg)
            still = len([t for t in s2["tasks"] if t["st"] == "skipped"])
            ov = 0
            for a, b in zip(s2["tasks"], s2["tasks"][1:]):
                if a["date"] == b["date"] and b["start"] < a["start"] + a["min"]:
                    ov += 1
            record("TC5", "Adaptive replanning (FR8)", "Skip two lessons, press 'Replan' on the Learn tab",
                   "Skipped lessons return to pending in upcoming free slots, with no overlaps",
                   f"skipped before: {sk}; skipped after: {still}; overlaps after replan: {ov}", sk >= 1 and still == 0 and ov == 0)
            ctx.close()

            # T6 persistence
            ctx, pg = new_page(browser)
            generate(pg)
            pg.click(".tabs button[data-v=today]")
            pg.click("[data-a=done]")
            pg.reload()
            pg.wait_for_timeout(300)
            done_after = len([t for t in state(pg)["tasks"] if t["st"] == "done"])
            on_learn = "hide" not in (pg.get_attribute("#today", "class") or "")
            record("TC6", "Progress persistence", "Generate, mark one lesson done, reload the page",
                   "Plan and progress are kept; app reopens on the Learn tab",
                   f"done lessons after reload: {done_after}; Learn tab shown: {on_learn}", done_after == 1 and on_learn)
            ctx.close()

            # T7 security: HTML in the job field must not execute
            ctx, pg = new_page(browser)
            generate(pg, job='<img src=x onerror="window.__xss=1">')
            pg.wait_for_timeout(300)
            executed = pg.evaluate("window.__xss === 1")
            shown = "<img" in pg.inner_text("#road")
            record("TC7", "Output escaping (NFR4)", "Enter job name containing an HTML image tag with an onerror script",
                   "Text is shown as plain text and no script runs",
                   f"script executed: {executed}; tag shown as text: {shown}", (not executed) and shown)
            ctx.close()

            # T8 AI path with a mocked server response
            ctx = browser.new_context(); pg = ctx.new_page(); pg.clock.install(time=CLOCK)
            pg.route("**/api/roadmap", lambda r: r.fulfill(status=200, content_type="application/json", body=json.dumps(MOCK_AI)))
            pg.goto(URL); generate(pg, "Robotics Engineer")
            s8 = state(pg)
            record("TC8", "AI roadmap path (FR4)", "Serverless endpoint answers with a valid JSON roadmap (mocked); press Generate",
                   "App uses the AI response (2 modules, 3 lessons) and labels the source as AI",
                   f"{len(s8['ms'])} modules, {len(s8['tasks'])} lessons; info: {s8['info'][:22]}...",
                   len(s8["ms"]) == 2 and len(s8["tasks"]) == 3 and "Claude (AI)" in s8["info"])
            ctx.close()

            # T9 accessibility semantics (NFR5)
            ctx, pg = new_page(browser)
            pressed = pg.eval_on_selector_all("#days button", "b=>b.every(x=>x.hasAttribute('aria-pressed'))")
            live = pg.eval_on_selector("#toast", "e=>e.getAttribute('aria-live')||e.getAttribute('role')")
            tabsel = pg.eval_on_selector_all(".tabs button", "b=>b.some(x=>x.getAttribute('aria-selected')==='true'||x.getAttribute('aria-current')==='page')")
            record("TC9", "Accessibility semantics (NFR5)", "Inspect day toggles, notification area and tab bar for screen-reader state",
                   "Day buttons expose pressed state; toasts are announced (aria-live/role); active tab is exposed",
                   f"all day buttons have aria-pressed: {pressed}; toast live region: {live}; active tab exposed: {tabsel}",
                   bool(pressed) and bool(live) and bool(tabsel))
            ctx.close()

            # T10 mobile layout (NFR5)
            ctx, pg = new_page(browser, width=390, height=800)
            generate(pg)
            overflow = pg.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            record("TC10", "Responsive layout (NFR5)", "Open at 390 px width, generate a roadmap, check for sideways scrolling",
                   "No horizontal overflow", f"horizontal overflow: {overflow} px", overflow <= 0)
            ctx.close()

            if os.environ.get("SNAP"):
                ctx, pg = new_page(browser)
                snap = "DAY TOGGLES\n" + pg.locator("#days").aria_snapshot() + "\n\nTABS\n" + pg.locator(".tabs").aria_snapshot()
                open(os.path.join(ROOT, "tests", os.environ["SNAP"]), "w").write(snap)
                ctx.close()
            ver = browser.version
            browser.close()
    finally:
        srv.terminate()

    out = {"date": datetime.date.today().isoformat(), "browser": "Chromium " + ver,
           "method": "Automated Playwright run with fixed fake clock", "results": results}
    with open(os.path.join(ROOT, "tests", "results.json"), "w") as f:
        json.dump(out, f, indent=2)
    print("passed", sum(r["status"] == "PASS" for r in results), "of", len(results))


if __name__ == "__main__":
    main()

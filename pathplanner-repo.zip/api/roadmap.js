// Vercel serverless function: POST /api/roadmap
// Holds the API key on the server so it never reaches the browser.
// Set the environment variable ANTHROPIC_API_KEY in your Vercel project settings.
const MODEL = "claude-haiku-5-5"; // a small, low-cost model is enough for roadmaps

function buildPrompt(job, months, tot) {
  return "You are a career learning planner for an Indian B.Tech student.\nTarget role: " + job +
    "\nTimeline: " + months + " months\nTotal study minutes available: about " + tot + " (a little less is fine).\n" +
    "Return ONLY JSON, no markdown: {\"milestones\":[{\"title\":string,\"tasks\":[{\"title\":string,\"minutes\":integer 20-60,\"q\":string}]}]}\n" +
    "Rules: 5 to 7 milestones ordered from beginner to job-ready; 4 to 8 tasks each; q is a short YouTube search query that finds a beginner-friendly tutorial for that task; include one portfolio project milestone and a final interview preparation milestone; total minutes must not exceed the limit above.";
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return res.status(500).json({ error: "Server is not configured" });

  // Validate input: never pass raw client text as the whole prompt.
  const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : (req.body || {});
  const job = String(body.job || "").trim().slice(0, 60);
  const months = [3, 6, 9, 12].includes(+body.months) ? +body.months : 12;
  const minutes = Math.max(600, Math.min(60000, Math.round(+body.minutes || 6000)));
  if (!job) return res.status(400).json({ error: "job is required" });

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: MODEL, max_tokens: 3000, messages: [{ role: "user", content: buildPrompt(job, months, minutes) }] })
    });
    if (!r.ok) return res.status(502).json({ error: "Upstream error" });
    const data = await r.json();
    const text = (data.content || []).map(b => b.text || "").join("");
    const a = text.indexOf("{"), b = text.lastIndexOf("}");
    if (a < 0 || b < a) return res.status(502).json({ error: "Bad model output" });
    return res.status(200).json(JSON.parse(text.slice(a, b + 1)));
  } catch (e) {
    return res.status(500).json({ error: "Failed to generate roadmap" });
  }
};
